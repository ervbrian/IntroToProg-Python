# ------------Persons.py Module ---------------#
# Desc:  Classes that hold Personal data
# Dev:   Brian Ervin
# Date:  03/08/2019
# ChangeLog:(When,Who,What)
# ---------------------------------------------#

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself")


# --- Make the class ---
class Person(object):
    """ Base Class for Personal data """

    # --Fields--
    __Counter = 0

    # --Constructor--
    def __init__(self, FirstName="", LastName="", DOB=""):
        # Attributes
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__DOB = DOB
        Person.__SetObjectCount()

    # --Properties--
    # FirstName
    @property  # getter(accessor)
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter  # (mutator)
    def FirstName(self, Value):
        self.__FirstName = Value

    # LastName
    @property  # getter(accessor)
    def LastName(self):
        return self.__LastName

    @LastName.setter  # (mutator)
    def LastName(self, Value):
        self.__LastName = Value

    # Date of Birth
    @property  # getter(accessor)
    def DOB(self):
        return self.__DOB

    @DOB.setter  # (mutator)
    def DOB(self, Value):
        self.__DOB = Value

    # --Methods--
    def ToString(self):
        """Explictly returns field data"""
        return self.FirstName + ',' + \
               self.LastName+ ',' + \
               self.DOB

    def __str__(self):
        """Implictly returns field data"""
        return self.ToString()

    @staticmethod
    def GetObjectCount():
        return Person.__Counter

    @staticmethod
    def __SetObjectCount():
        Person.__Counter += 1

    # --End of class--

