# ------------Customers.py ---------------#
# Desc:  Classes that hold customer data
# Dev:   Brian Ervin
# Date:  03/09/2019
# ChangeLog:(When,Who,What)
# ---------------------------------------------#
import Persons

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself")


# --- Make child class of Person ---
class Customer(Persons.Person):
    """ Class for Customer data """

    # Fields
    __Counter = 0

    # --Constructor--
    def __init__(self, Id="", Email="", StartDate=""):
        # Attributes
        self.__Id = Id
        self.__Email = Email
        self.__StartDate = StartDate
        Customer.__SetObjectCount()

    # --Properties--
    # Id
    @property  # getter(accessor)
    def Id(self):
        return self.__Id

    @Id.setter  # (mutator)
    def Id(self, Value):
        self.__Id = Value

    # Email
    @property  # getter(accessor)
    def Email(self):
        return self.__Email

    @Email.setter  # (mutator)
    def Email(self, Value):
        self.__Email = Value

    # StartDate
    @property  # getter(accessor)
    def StartDate(self):
        return self.__StartDate

    @StartDate.setter  # (mutator)
    def StartDate(self, Value):
        self.__StartDate = Value

    # --Methods--

    def ToString(self):
        """Explictly returns field data"""
        PersonDetails = super().ToString() # ToString details inherited from Person class
        return str(self.Id) + ',' + self.Email + ',' + self.StartDate + ',' + PersonDetails

    def __str__(self):
        """Implictly returns field data"""
        return self.ToString()

    @staticmethod
    def GetObjectCount():
        return Customer.__Counter

    @staticmethod
    def __SetObjectCount():
        Customer.__Counter += 1

    # --End of Class --


class CustomerList(object):
    """ Static class for holding a list of Customer data """

    # --Fields--
    __lstCustomers = []  # a list with Employee objects

    # --Methods--
    @staticmethod
    def AddCustomer(Customer):
        if (str(Customer.__class__) == "<class 'Customers.Customer'>"):
            CustomerList.__lstCustomers.append(Customer)
        else:
            raise Exception("Only Customer objects can be added to this list")

    @staticmethod
    def ToString():
        """Explictly returns field data"""
        strData = "Id,FirstName,LastName,Date of Birth,Start Date,Email\n"
        for item in CustomerList.__lstCustomers:
            strData += str(item.Id) + "," + \
                       item.FirstName + "," + \
                       item.LastName + "," + \
                       item.DOB + "," + \
                       item.StartDate + "," + \
                       item.Email + "," + "\n"
        return strData

    @staticmethod
    def __str__():  # This overrides the original method as well
        """Implictly returns field data"""
        strData = CustomerList.ToString
        return strData

    # --End of Class --

