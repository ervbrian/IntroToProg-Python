#-------------------------------------------------#
# Title: CustomerApp.py
# Dev:   Brian Ervin
# Date:  03/09/2019
# Desc: This application manages customer data
# ChangeLog: (Who, When, What)
#
#-------------------------------------------------#

if __name__ == "__main__":
    import DataProcessor, Customers
else:
    raise Exception("This file was not created to be imported")


#-- Processing --#
def ProcessCustomerData(Id, FirstName, LastName, Email, DOB, StartDate):

    '''
    Generate Customer object and populate fields. Append object to CustomerList.
    :param Id: integer
    :param FirstName: string
    :param LastName: string
    :param Email: string
    :param DOB: string
    :param StartDate: string
    :return: None
    '''

    try:
        #Create Customer object
        objE = Customers.Customer()
        objE.Id = Id
        objE.FirstName = FirstName
        objE.LastName = LastName
        objE.Email = Email
        objE.DOB = DOB
        objE.StartDate = StartDate
        Customers.CustomerList.AddCustomer(objE)
    except Exception as e:
        print(e)


def SaveDataToFile():

    '''
    Write customer data to file in CSV format
    '''

    try:
        objF = DataProcessor.File()
        objF.FileName = "CustomerData.txt"
        objF.TextData = Customers.CustomerList.ToString()
        print("Successfully processed customer data and stored in CSV format here: " + objF.FileName)
        objF.SaveData()
    except Exception as e:
        print(e)


if __name__ == "__main__":

    # Create list of tuples containing customer details
    cust_list = [(1, 'Brian', 'Ervin', 'brian.ervin@gmail.com', '04/18/1989', '3/10/2019'),
                (2, 'John', 'Smith', 'john.smith@gmail.com', '03/19/1978', '3/10/2019'),
                (3, 'Sue', 'Jones', 'sue.jones@gmail.com', '09/20/1965', '3/10/2019')]

    # Process all customer data from cust_list
    for cust in cust_list:
        ProcessCustomerData(cust[0], cust[1], cust[2], cust[3], cust[4], cust[5])

    # Store processed data
    SaveDataToFile()
    print("{} total customers processed".format(Customers.Customer.GetObjectCount()))

