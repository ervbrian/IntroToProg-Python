#-----------------------------#
# Title: Todo.py
# Dev: BrianErvin
# Date: Feb 9, 2019
# ChangeLog: (When, Who, What)
#  2019-02-09, Brian Ervin, Created Version 1.0
#  2019-02-09, Brian Ervin, Converted to Version 2.0 using class static methods
#-----------------------------#

"""
Purpose: Manage ToDo list

Usage:
    python Todo.py

Steps:
    Import existing tasks from CSV input file
    Present menu to user with the following options:
        1) Show current tasks
        2) Add new task
        3) Remove existing task
        4) Save data to file
        5) Exit
    Continue prompting user with menu options until option 5 is chosen
"""

class ManageTasks():

    '''
    Class to manage ToDo list tasks
    '''

    @staticmethod
    def ImportTasksFromTerminal():
        """
        Add one or more tasks based on user input

        :return: lstTaskTable (List of dictionaries containing task info)
        """
        # Create task table to store todo item details gathered from user
        lstTaskTable = []

        # Continuously prompt user for task, priority details until "e" is entered
        # Add task and priority details to a dictionary
        # Append dictionary to task table list
        # Return task table
        while (True):
            strTaskName = input("Task (Enter 'e' to end): ")
            if strTaskName == "e": break
            strTaskPriority = input("Priority: ")
            dicTask = {"Name": strTaskName, "Priority": strTaskPriority}
            lstTaskTable.append(dicTask)
        return lstTaskTable

    @staticmethod
    def ImportTasksFromCSV(objInputFile):
        """
        Import tasks / todo list from CSV file

        :param objInputFile: Input CSV file containing two fields - Task,Priority
        :return: lstTaskTable (List of dictionaries)
        """
        lstTaskTable = []

        objTodoFile = open(objInputFile, "r")

        for row in objTodoFile:
            if len(str(row).strip()) != 0:
                taskname, taskpriority = row.split(",")
                dicTask = {"Name": taskname, "Priority": taskpriority}
                lstTaskTable.append(dicTask)
        return lstTaskTable


    @staticmethod
    def DisplayTasks(lstTasks):
        """
        Display tasks / todo items to user

        :param lstTasks: List of dictionaries containing task info
        :return: NONE
        """

        # Print Header
        print("-" * 10, end="")
        print(" ToDo List ", end="")
        print("-" * 10)

        # Iterate through task list. Print Name and Priority details.
        for task in lstTasks:
            print("{}\n  Priority: {}".format(task["Name"], task["Priority"]))

        # Print Footer
        print("-" * 30)


    @staticmethod
    def WriteOutputToCSV(lstTasks, objOutputFile):
        """
        Store todo list to CSV file

        :param lstTasks: List of dictionaries containing task info
        :param objOutputFile: Filename used for data storage
        :return: NONE
        """
        # Open output file for writing
        objTodoFile = open(objOutputFile, "w")

        # Iterate through task list elements
        # If element is not empty, write Name and Priority details to output file
        for row in lstTasks:
            if len(str(row).strip()) != 0:
                objTodoFile.write(str(row["Name"] + ","))
                objTodoFile.write(str(row["Priority"] + "\n"))

        # Close output file
        objTodoFile.close()

        print("Task data written to file...")


    @staticmethod
    def RemoveTask(lstTasks):
        """
        Remove existing task from todo list

        :param lstTasks: List of dictionaries containing task info
        :return: intTaskIndex (Index number of list element to be removed)
        """
        # Fetch details from user on which task to remove
        strTaskToRemove = input("Enter the task name to remove: ")

        try:
            # Determine list index value for task to be removed using list comprehension and next() method
            intTaskIndex = next(task for task in lstTasks if task["Name"] == strTaskToRemove)
        except:
            print("Task not found")
            # Set index value to a zero length string
            intTaskIndex = ""

        return intTaskIndex


def main():

    inputFile = "Todo.csv"

    # Determine starting task list
    try:
        # Create list of dictionaries containing task data imported from CSV file
        lstTasks = ManageTasks.ImportTasksFromCSV(inputFile)
    except:
        print("Error opening input file. Continuing with no initial tasks...")
        # Create an empty list to store task details
        lstTasks = []

    # Continuously prompt user with menu options until option "5" is used
    # Fetch user's choice and execute corresponding function
    while(True):
        strMenuChoice = input("""
        What would you like to do?
        1) Show current tasks
        2) Add new task
        3) Remove existing task
        4) Save data to file
        5) Exit

        Enter: """)

        if strMenuChoice == "1":
            ManageTasks.DisplayTasks(lstTasks)
        elif strMenuChoice == "2":
            lstAdditionalTasks = ManageTasks.ImportTasksFromTerminal()
            lstTasks.extend(lstAdditionalTasks)
        elif strMenuChoice == "3":
            try:
                lstTasks.remove(ManageTasks.RemoveTask(lstTasks))
            except:
                print("Error removing task...")
        elif strMenuChoice == "4":
            ManageTasks.WriteOutputToCSV(lstTasks, inputFile)
        elif strMenuChoice == "5":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a number between 1-5...")


if __name__ == '__main__':
    main()
