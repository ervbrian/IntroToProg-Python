#-----------------------------#
# Title: BasicMath.py
# Dev: BrianErvin
# Date: Jan 15, 2019
# ChangeLog: (When, Who, What)
#  2019-01-15, Brian Ervin, Created Version 1.0
#-----------------------------#

"""
Purpose: Calculate sum, difference, product and quotient values from two input values

Steps:
    Request two floating point values from the user.
    Sum, difference, product and quotient values are calculated and stored.
    Display calculated values to the user.
"""

# Gather user input values and convert type to float
fltNumber1 = float(input("Enter a number: "))
fltNumber2 = float(input("Enter another number: "))

# Process answers based on user input
fltSum = fltNumber1 + fltNumber2
fltDifference = fltNumber1 - fltNumber2
fltProduct = fltNumber1 * fltNumber2
fltQuotient = fltNumber1 / fltNumber2

# Print answers to the terminal
print("\n", "*" * 20)
print("The sum of {} and {} is: {}".format(fltNumber1, fltNumber2, fltSum))
print("The difference of {} and {} is: {}".format(fltNumber1, fltNumber2, fltDifference))
print("The product of {} and {} is: {}".format(fltNumber1, fltNumber2, fltProduct))
print("The quotient of {} and {} is: {}".format(fltNumber1, fltNumber2, fltQuotient), end = '')
print("\n", "*" * 20)