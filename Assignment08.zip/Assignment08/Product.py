# ----------------------------- #
# Title: Product.py
# Dev: Brian Ervin
# Date: Mar 1, 2019
# ChangeLog: (When, Who, What)
#  2019-03-01, Brian Ervin, Created Version 1.0
# ----------------------------- #

class Product(object):

    """ Base Class for Product Data """
    #-------------------------------------#
    #Desc:  Holds Product data
    #Dev:   Brian Ervin
    #Date:  03/01/2019
    #ChangeLog:(When,Who,What)
    #-------------------------------------#

    # Product initializer / constructor
    def __init__(self):
        # Attributes
        self.__ID = ''
        self.__Name = ''
        self.__Price = ''

    # Generate CSV data for object
    def ToString(self):
        return self.__ID + ',' + self.__Name + ',' + self.__Price

    def __str__(self):
        return self.ToString()

    @property  # getter(accessor)
    def ID(self):
        return self.__ID

    @ID.setter  # (mutator)
    def ID(self, Value):
        self.__ID = Value

    @property  # getter(accessor)
    def Name(self):
        return self.__Name

    @Name.setter  # (mutator)
    def Name(self, Value):
        self.__Name = Value

    @property  # getter(accessor)
    def Price(self):
        return self.__Price

    @Price.setter  # (mutator)
    def Price(self, Value):
        self.__Price = Value


class Processing():

    """ Base Class for Product Data Processing """
    #-------------------------------------#
    #Desc:  Processing product data
    #Dev:   Brian Ervin
    #Date:  03/01/2019
    #ChangeLog:(When,Who,What)
    #-------------------------------------#

    def WriteProductUserInput(File):

        '''
        Write product details to CSV file based on user input

        :param File: File object handler for CSV input file
        :return: None
        '''

        try:
            print("\n\nType in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")

            # Prompt user for product details and generate Product object for each
            while (True):
                strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                if (strUserInput.lower() == "exit"):
                    break
                else:
                    # Create Product instance based on strUserInput
                    objProduct = Product()
                    objProduct.ID = strUserInput.split(',')[0]
                    objProduct.Name = strUserInput.split(',')[1]
                    objProduct.Price = strUserInput.split(',')[2]

                    # Write product object details to file
                    File.write(objProduct.ToString() + "\n")
        except Exception as e:
            print("Error: " + str(e))

    def ReadAllFileData(File):

        '''
        Read CSV file containing product details and generate objects

        :param File: File object handler for CSV input file
        :return: None
        '''

        # List to hold product objects as they are created
        lstProductObjects = []

        try:
            File.seek(0)
            data = File.read()

            # Parse CSV data and create product object for each entry
            for strLine in data.split('\n'):
                if len(strLine) != 0:
                    objProduct = Product()
                    objProduct.ID = strLine.split(',')[0]
                    objProduct.Name = strLine.split(',')[1]
                    objProduct.Price = strLine.split(',')[2]
                    lstProductObjects.append(objProduct)

        except Exception as e:
            print("Error: " + str(e))

        # Inventory header
        print('\n\n===== Product Inventory ({} total items) ====='.format(len(lstProductObjects)))

        # Generate inventory list and display
        for objProduct in lstProductObjects:
            print(objProduct.ToString())


def main():

    try:
        with open("Products.txt", "r+") as objFile:
            Processing.ReadAllFileData(objFile)
            Processing.WriteProductUserInput(objFile)
            Processing.ReadAllFileData(objFile)
    except FileNotFoundError as e:
        print("Error: " + str(e) + "\n Please check the file name")
    except Exception as e:
        print("Error: " + str(e))
    finally:
        if(objFile != None):objFile.close()


if __name__ == '__main__':
    main()

