#-----------------------------#
# Title: HomeInventory.py
# Dev: BrianErvin
# Date: Feb 3, 2019
# ChangeLog: (When, Who, What)
#  2019-02-03, Brian Ervin, Created Version 1.0
#-----------------------------#

"""
Purpose: Store household inventory to a text file

Usage:
    ./HomeInventory.py $output_file

Steps:
    Request item name from user
    Request monetary value for item
    Continue prompting for item/value data from user
    Append HouseholdInventory.csv with new item(s)
"""

import sys

lstItemList = [] # List to contain item tuples

# Continue prompting for items until a blank strItemName is used
while[True]:
    # Gather item details from user
    # Break out of while loop if strItemName is blank (zero length)
    strItemName = input("Enter item name (Leave blank to exit): ")
    if (len(strItemName) == 0): break
    fltItemPrice = input("Enter value of {}: $".format(strItemName))

    # Create tuple with item info
    tplItemInfo = (strItemName, fltItemPrice)

    # Append tplItemInfo to item list
    lstItemList.append(tplItemInfo)

# Request if user wants to store data to file
strStoreToFile = input("Would you like to save item data to file? (Y/N): ")

if(strStoreToFile.upper() == 'Y'):

    # Determine output file
    if (len(sys.argv) == 2):
        # Set output file to user provided argument value if provided
        objOutputFile = sys.argv[1]
    else:
        # Set output file to the current directory as default if no argument supplied
        objOutputFile = "HomeInventory.csv"

    # Create CSV Header
    strHeader = "ITEM,VALUE"

    # Create object pointing to output file and open file for storing data
    print("Using {} to store data...".format(objOutputFile))
    objHomeInventory = open(objOutputFile, "a")

    # Add Header to CSV
    objHomeInventory.write(strHeader + '\n')

    # Store item and value data to HomeInventory.csv
    for strItem in lstItemList:
        objHomeInventory.write(strItem[0] + ',')
        objHomeInventory.write(strItem[1] + '\n')
    print("Wrote data to file successfully")

    # Close file
    objHomeInventory.close()
else:
    print("Data not written to file. Exiting...")
