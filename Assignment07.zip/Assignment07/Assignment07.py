#-----------------------------#
# Title: Assignment07.py
# Dev: BrianErvin
# Date: Feb 25, 2019
# ChangeLog: (When, Who, What)
#  2019-02-25, Brian Ervin, Created Version 1.0
#-----------------------------#

"""
Purpose: Store employee database in binary format

Usage:
    python Assignment07.py
"""

import pickle

# Gather employee details from user
name = input("Enter employee name: ")
position = input("Enter position/title: ")

# Create a new dictionary containing employee details
employee_dict = {'name': name,
                 'position': position}

# Specify file to store pickled data
pickle_file = 'employee.bin'

# Open pickle file and store employee_dict object
try:
    with open(pickle_file, "wb") as f:
        pickle.dump(employee_dict, f)
    f.close()
except pickle.PicklingError as e:
    print("Failed to pickle object. Please ensure this object type is supported -> " + e)
except pickle.PickleError as e:
    print("An error with pickle has occurred -> " + e)
except Exception as e:
    print("Generic error occurred -> " + e)
