#-----------------------------#
# Title: A Simple Test Script
# Dev: BrianErvin
# Date: Jan 8, 2019
# ChangeLog: (When, Who, What)
#  2019-01-08, Brian Ervin, Created Version 1.0
#-----------------------------#

def main():
    # Assign 'user' variable to user's input
    user = input("Please enter your name: ")

    # Print welcome statement to user, including their name.
    print("Welcome, {}!".format(user))

main()