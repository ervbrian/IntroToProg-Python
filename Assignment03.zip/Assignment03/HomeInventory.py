#-----------------------------#
# Title: HomeInventory.py
# Dev: BrianErvin
# Date: Jan 22, 2019
# ChangeLog: (When, Who, What)
#  2019-01-22, Brian Ervin, Created Version 1.0
#-----------------------------#

import sys

"""
Purpose: Store household inventory to a text file

Usage:
    ./HomeInventory.py $output_file

Steps:
    Determine output file location
    Request item name from user
    Request monetary value for item
    Append output file with new item

Caveat:
    This will only run on Linux/Mac OS. Windows does not have a /tmp directory
"""

# Determine output file
if (len(sys.argv) == 2):
    # Set output file to user provided argument value if provided
    objOutputFile = sys.argv[1]
else:
    # Set output file to /tmp directory as default if no argument supplied
    objOutputFile = "/tmp/HomeInventory.txt"

# Create object pointing to output file and open file for storing data
print("Using {} to store data...".format(objOutputFile))
objHomeInventory = open(objOutputFile, "a")

while[True]: # Continue prompting for items until a blank strItemName is used
    # Gather item details from user
    # Break out of while loop if strItemName is blank (zero length)
    strItemName = input("Enter item name (Leave blank to exit): ")
    if (len(strItemName) == 0): break
    fltItemPrice = input("Enter value of {}: $".format(strItemName))

    # Store item and value to HomeInventory.txt
    objHomeInventory.write(strItemName + " $")
    objHomeInventory.write(fltItemPrice + "\n")
    print("Added {} to {}".format(strItemName, objOutputFile))

objHomeInventory.close()